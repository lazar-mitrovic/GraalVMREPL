# frozen_string_literal: true
##
# A Module included in a class with \#include
#
#   RDoc::Include.new 'Enumerable', 'comment ...'

class RDoc::Include < RDoc::Mixin

end

