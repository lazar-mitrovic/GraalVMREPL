# frozen_string_literal: false
#
#   version.rb - shell version definition file
#       $Release Version: 0.7$
#       $Revision$
#       by Keiju ISHITSUKA(keiju@ruby-lang.org)
#
# --
#
#
#

class Shell # :nodoc:
  VERSION = "0.7"
  @RELEASE_VERSION = VERSION
  @LAST_UPDATE_DATE = "07/03/20"
end
